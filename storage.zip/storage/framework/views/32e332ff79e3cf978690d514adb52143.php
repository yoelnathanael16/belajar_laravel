<?php $__env->startSection('title', 'Profil'); ?>
<?php $__env->startSection('page', 'profil.html'); ?>
<?php $__env->startSection('script', 'profile'); ?>

<?php $__env->startSection('content'); ?>
    <section class="wrap prof" id="profRoot" hidden>
        <aside class="card">
            <div class="avatar" id="av"></div>
            <h2 id="pn"></h2>
            <p id="pe" class="small"></p>
            <div class="mini">
                <div><b id="c1">0</b>Sedang diproses</div>
                <div><b id="c2">0</b>Total Pesanan</div>
            </div>
            <a class="btn" href="<?php echo e(route('booking')); ?>">Buat Booking Baru</a>
            <button class="btn ghost" id="logout">Keluar</button>
        </aside>
        <div class="card">
            <h1>Pesanan Saya</h1>
            <p class="small">Status pesanan diperbarui setelah admin memberi keputusan lewat WhatsApp</p>
            <div class="tabs">
                <button class="on" data-t="p">Sedang diproses</button>
                <button data-t="h">Riwayat</button>
            </div>
            <div id="orders"></div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pawon.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar-laravel\resources\views/pawon/profile.blade.php ENDPATH**/ ?>