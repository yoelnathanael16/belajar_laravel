<!DOCTYPE html> 
<html lang="id">
    <head> 
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
        <title>Latihan Bootstrap</title>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?> 
    </head> 
    <body>
        <nav class="navbar navbar-expand-lg bg-primary" data-bs-theme="dark"> 
            <div class="container">
                <a class="navbar-brand" href="#">KampusKu</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menuUtama" aria-controls="menuUtama" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button> 
                <div class="collapse navbar-collapse" id="menuUtama"> 
                    <ul class="navbar-nav ms-auto"> 
                        <li class="nav-item"> 
                            <a class="nav-link active" href="#">Home</a> 
                        </li> 
                        <li class="nav-item"> 
                            <a class="nav-link" href="#">Mahasiswa</a> 
                        </li> 
                        <li class="nav-item"> 
                            <a class="nav-link" href="#">Mata Kuliah</a> 
                        </li> 
                        <li class="nav-item"> 
                            <a class="nav-link" href="#">Tugas</a> 
                        </li> 
                    </ul> 
                </div> 
            </div> 
        </nav>
        <div class="container py-5">
            <h2 class="text-center mb-4">Menu Mahasiswa</h2>
            <p class="text-center mb-4">Yoel Nathanael - 2802445766</p>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card h-100 shadow-sm materi-card">
                        <div class="card-body">
                            <h5 class="card-title">Materi</h5>
                            <p class="card-text"> Materi perkuliahan. </p>
                            <a href="#" class="btn btn-primary">Lihat</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card h-100 shadow-sm tugas-card">
                        <div class="card-body">
                            <h5 class="card-title">Tugas</h5>
                            <p class="card-text"> Daftar tugas mahasiswa. </p>
                            <a href="#" class="btn btn-success">Lihat</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card h-100 shadow-sm profil-card">
                        <div class="card-body">
                            <h5 class="card-title">Profil</h5>
                            <p class="card-text"> Data mahasiswa. </p>
                            <a href="#" class="btn btn-warning">Lihat</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html><?php /**PATH C:\xampp\htdocs\belajar-laravel\resources\views/welcome.blade.php ENDPATH**/ ?>