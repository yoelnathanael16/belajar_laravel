<header class="nav">
    <a class="brand" href="<?php echo e(route('home')); ?>">
        <img src="<?php echo e(Vite::asset('resources/images/pawon/logo.png')); ?>" alt="Logo Pawon Ratu Roso">
        <span>Pawon Ratu Roso</span>
    </a>
    <button class="burger" aria-label="Buka menu" aria-expanded="false">&#9776;</button>
    <nav id="mainnav">
        <a href="<?php echo e(route('home')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['on' => request()->routeIs('home')]); ?>">Beranda</a>
        <a href="<?php echo e(route('about')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['on' => request()->routeIs('about')]); ?>">Tentang Kami</a>
        <a href="<?php echo e(route('menu')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['on' => request()->routeIs('menu')]); ?>">Menu</a>
        <a href="<?php echo e(route('booking')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['on' => request()->routeIs('booking')]); ?>">Booking</a>
        <a href="<?php echo e(route('contact')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['on' => request()->routeIs('contact')]); ?>">Hubungi Kami</a>
        <span id="authSlot">
            <a class="btn-nav" href="<?php echo e(route('register')); ?>">Daftar</a>
        </span>
    </nav>
</header>
<?php /**PATH C:\xampp\htdocs\belajar-laravel\resources\views/pawon/partials/header.blade.php ENDPATH**/ ?>