<?php $__env->startSection('title', 'Booking'); ?>
<?php $__env->startSection('page', 'booking.html'); ?>
<?php $__env->startSection('script', 'booking'); ?>

<?php $__env->startSection('content'); ?>
    <section class="wrap">
        <div id="gate" class="gate card" hidden>
            <h2>Akun Diperlukan Untuk Booking</h2>
            <p>Daftar hanya butuh waktu singkat, dan Anda bisa langsung memesan meja setelahnya.</p>
            <a class="btn" href="<?php echo e(route('register')); ?>">Daftar Sekarang</a>
            <a class="btn ghost" href="<?php echo e(route('login')); ?>">Sudah punya akun? Masuk</a>
            <a class="ulink" href="<?php echo e(route('home')); ?>">Kembali ke Beranda</a>
        </div>
        <div id="wiz" class="wiz card" hidden>
            <ol class="steps" id="steps"></ol>
            <div id="pane"></div>
            <div class="wizbar">
                <button class="btn ghost" id="back">Kembali</button>
                <span id="sum"></span>
                <button class="btn" id="next">Lanjut</button>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pawon.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar-laravel\resources\views/pawon/booking.blade.php ENDPATH**/ ?>