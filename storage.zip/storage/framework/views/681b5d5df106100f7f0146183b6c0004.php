<?php $__env->startSection('title', 'Tentang Kami'); ?>
<?php $__env->startSection('page', 'tentang-kami.html'); ?>
<?php $__env->startSection('script', 'about'); ?>

<?php $__env->startSection('content'); ?>
    <section class="wrap">
        <div class="about">
            <div>
                <img src="<?php echo e(Vite::asset('resources/images/pawon/about.jpg')); ?>" alt="Sajian prasmanan">
                <div class="stats">
                    <div><b>4.7</b>Penilaian Pelanggan</div>
                    <div><b>40+</b>Menu</div>
                </div>
            </div>
            <p class="lead">Pawon berarti dapur dalam bahasa Jawa, dan di sinilah rasa Jawa yang hangat kami jaga. Pawon Ratu Roso menyajikan sayur, lauk, dan jajanan rumahan dengan bumbu yang mengingatkan Anda pada masakan nenek. Rasakan kenikmatan sederhana yang membuat rindu untuk kembali.</p>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pawon.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar-laravel\resources\views/pawon/about.blade.php ENDPATH**/ ?>