<?php $__env->startSection('title', 'Daftar'); ?>
<?php $__env->startSection('page', 'daftar.html'); ?>
<?php $__env->startSection('script', 'register'); ?>
<?php $__env->startSection('body_class', 'authpage'); ?>

<?php $__env->startSection('content'); ?>
    <section class="authbox">
        <p class="kick">Halaman daftar</p>
        <h1>Yuk, Gabung di Pawon Ratu Roso</h1>
        <p>Buat akun agar pesan meja jadi lebih mudah.</p>
        <form id="authForm" data-mode="daftar" novalidate>
            <label>Nama lengkap
                <input name="name" type="text" required autocomplete="name">
            </label>
            <label>Email
                <input name="email" type="email" required autocomplete="email">
            </label>
            <label>Kata sandi
                <input name="password" type="password" required autocomplete="new-password">
            </label>
            <p class="err" id="err" role="alert" hidden></p>
            <button class="btn" type="submit">Buat Akun</button>
        </form>
        <p class="alt">Sudah punya akun? <a href="<?php echo e(route('login')); ?>">Masuk di sini</a></p>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pawon.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar-laravel\resources\views/pawon/register.blade.php ENDPATH**/ ?>