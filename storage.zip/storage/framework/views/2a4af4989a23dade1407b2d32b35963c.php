<?php
    // Peta nama berkas lama -> URL rute, dibaca oleh resources/js/pawon/app.js (Pawon.url)
    $pawonRoutes = [
        'index.html' => route('home'),
        'tentang-kami.html' => route('about'),
        'menu.html' => route('menu'),
        'booking.html' => route('booking'),
        'hubungi-kami.html' => route('contact'),
        'masuk.html' => route('login'),
        'daftar.html' => route('register'),
        'profil.html' => route('profile'),
    ];
?>
<!DOCTYPE html>
<html lang="id">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title><?php echo $__env->yieldContent('title'); ?> | Pawon Ratu Roso</title>
        <link rel="icon" href="<?php echo e(Vite::asset('resources/images/pawon/logo.png')); ?>">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/pawon.css', 'resources/js/pawon/pages/' . trim($__env->yieldContent('script')) . '.js']); ?>
    </head>
    <body class="<?php echo $__env->yieldContent('body_class'); ?>" data-page="<?php echo $__env->yieldContent('page'); ?>" data-routes="<?php echo e(json_encode($pawonRoutes)); ?>">
        <?php echo $__env->make('pawon.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <?php echo $__env->make('pawon.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php if(isset($menu)): ?>
            <script type="application/json" id="pawon-menu"><?php echo json_encode($menu, JSON_HEX_TAG | JSON_UNESCAPED_UNICODE, 512) ?></script>
        <?php endif; ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\belajar-laravel\resources\views/pawon/layouts/app.blade.php ENDPATH**/ ?>