<?php $__env->startSection('title', 'Menu'); ?>
<?php $__env->startSection('page', 'menu.html'); ?>
<?php $__env->startSection('script', 'menu'); ?>

<?php $__env->startSection('content'); ?>
    <section class="wrap">
        <div class="menutools">
            <input id="q" type="search" placeholder="Cari menu, mis. ayam, kopi, pepes" aria-label="Cari menu">
            <span id="count"></span>
        </div>
        <div id="menuRoot"></div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pawon.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\belajar-laravel\resources\views/pawon/menu.blade.php ENDPATH**/ ?>